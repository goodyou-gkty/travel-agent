package com.ewheelz.FormBean;

public class PickupFormBean {

	private int pid,bid,rid;
    String pname;
    
    
    
    public int getpid() {
		return pid;
	}
	public void setpid(int pid) {
		this.pid = pid;
	}
	
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public int getRid() {
		return rid;
	}
	public void setRid(int rid) {
		this.rid = rid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
    
    
    
	
}
